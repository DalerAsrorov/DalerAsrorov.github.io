public class Test {

   public static void main(String args[]){
       int a = 10;
       int b = 2;
       if ( a % b == 0 )
       {
             System.out.println(a + " is divisible by "+ b);
       }
       else
       {
             System.out.println(a + " is not divisible by " + b);
       }
   }
}
