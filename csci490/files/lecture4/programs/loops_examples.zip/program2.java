package usc.edu;
import java.util.*;

public class Program {
    public static void main(String[] args) {
    	// Use nested for-loops.
    	for (int i = 0; i < 3; i++) {
    	    for (int y = 0; y < 3; y++) {
    		      System.out.println(i + "," + y);
    	    }
    	}

      // Given a num, returns how many times can we divide it by 2 to get down to 1.
      int count = 0;   // count how many divisions we've done
      while (num >= 1) {
        num = num / 2;
        count++;
      }
      System.out.println("The result is " + count);

      // do while
      int x = 10;
      do {
         System.out.print("value of x : " + x );
         x++;
         System.out.print("\n");
      }while( x < 20 );

    }
}
